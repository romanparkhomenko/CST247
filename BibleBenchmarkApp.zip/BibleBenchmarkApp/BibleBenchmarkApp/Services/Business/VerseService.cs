﻿using BibleBenchmarkApp.Models;
using BibleBenchmarkApp.Services.Business.Data;
using BibleBenchmarkApp.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Unity;


/* Roman Parkhomenko CST-247 02/21/2019
 * A service to query or post verses.
 */
namespace BibleBenchmarkApp.Services.Business {
    public class VerseService {
        private DAO dao;

        [Dependency]
        public ILogger logger = new MyLogger2();

        public VerseService(VerseModel model) {
            dao = new DAO(model);
        }

        public List<string> SearchVerses() {
            logger.Info("Entered SearchVerses Method");
            List<string> verse = dao.SearchVerse();
            if (verse[0] != "No results found!") {
                logger.Info("Verse: " + verse[4]);
            } else {
                logger.Info("No results found");
            }
            return verse;
        }

        public bool InsertVerse() {
            logger.Info("Entered InsertVerse Method");
            if (dao.CheckExisting()) {
                dao.InsertVerse();
                logger.Info("Added verse");
                return true;
            } else {
                logger.Error("Verse already exists");
                return false;
            }
        }
    }
}