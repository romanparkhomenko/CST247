﻿using BibleBenchmarkApp.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

/* Roman Parkhomenko CST-247 02/21/2019
 * This controller sends you home.
 */
namespace BibleBenchmarkApp.Controllers
{
    public class HomeController : Controller
    {
        [Unity.Dependency]
        public ILogger logger = new MyLogger2();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
    }
}