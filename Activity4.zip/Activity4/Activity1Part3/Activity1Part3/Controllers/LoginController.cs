﻿using Activity1Part3.Models;
using Activity1Part3.Services.Business;
using Activity1Part3.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using NLog;

namespace Activity1Part3.Controllers
{
    public class LoginController : Controller
    {
       
        private static MyLogger1 logger = MyLogger1.GetInstance();

        // GET: Login
        [HttpGet]
        public ActionResult Index()
        {
            return View("Login");
        }

        [HttpPost]
        public ActionResult Login(UserModel model) {
            logger.Info("Entering LoginController.Login()");
            logger.Info("Parameters are: " + new JavaScriptSerializer().Serialize(model));

            if (!ModelState.IsValid) {
                logger.Error("Exception LoginController.Login() " + ModelState.IsValid);
                return View("Login");
            }

            SecurityService authService = new SecurityService();

            bool authorized = authService.Authenticate(model);

            if (authorized) {
                logger.Info("Exit LoginController.Login() with login passing");
                return View("LoginPassed", model);
            } else {
                logger.Info("Exit LoginController.Login() with login failing");
                return View("LoginFailed");
            }
        }
    }
}