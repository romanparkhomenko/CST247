﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Activity2PartOne.Models;

namespace Activity2PartOne.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            List < UserModel > userList = new List<UserModel>();
            UserModel user1 = new UserModel("Roman", "password", "roman@test.com", "123-456-7890");
            UserModel user2 = new UserModel("Zach", "password1", "zach@test.com", "123-456-7890");
            UserModel user3 = new UserModel("David", "password2", "david@test.com", "123-456-7890");

            userList.Add(user1);
            userList.Add(user2);
            userList.Add(user3);

            return View("Test", userList);
        }
    }
}