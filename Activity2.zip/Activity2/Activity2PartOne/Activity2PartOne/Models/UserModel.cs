﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Activity2PartOne.Models {
    public class UserModel {
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }


        public UserModel() {
            // Do nothing.
        }

        public UserModel(string username, string password, string email, string phone) {
            this.Username = username;
            this.Password = password;
            this.EmailAddress = email;
            this.PhoneNumber = phone;
        }
    }
}